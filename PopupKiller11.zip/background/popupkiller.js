/* Brian Henson 1/24/2018 */

// basically a copy of all the info in storage
var globalstorage = [];
var globalregex = [];

function onError(error) {
	console.error(`PopupKiller unknown error: ${error}`);
}

function removeStorage(urltoremove) {
	var removingItem = browser.storage.local.remove(urltoremove);
	removingItem.then(() => {
		console.log("PopupKiller: removed " + urltoremove + " from klist");
		readStorage();
	}, onError);
}

function clearStorage() {
	var clearKlist = browser.storage.local.clear();
	clearKlist.then(() => {
		console.log("PopupKiller: wiped out entire klist");
		readStorage();
	}, onError);
}




function addHit(urltoinc, num) {
 	var increment = browser.storage.local.set( { [urltoinc] : num } );
	increment.then(() => {
		console.log("PopupKiller: incremented hits for " + urltoinc + ", now at " + num);
	}, onError);
	// if I want to keep track of the most recently killed site, this is where
	// the code would be added!
}



function addStorage(urltoadd) {
	var setting = browser.storage.local.set( { [urltoadd] : 0 } );
	setting.then(() => {
		console.log("PopupKiller: added " + urltoadd + " to klist");
		readStorage();
	}, onError);
}
function readStorage() {
	var gettingItem = browser.storage.local.get(); // get everything
	gettingItem.then(copyKlist, onError);
}
function copyKlist(result) {
	// creates a list of pattern:hits pairs, list of lists
	globalstorage = Object.entries(result);
	globalregex = [];
	let entry = null;
	for(entry of globalstorage) {
		let k = entry[0];
		// NOTE: if I want the user to input real RegEx instead of pseudo-regex, comment these 3
		k = "^" + k + "$";			// 1: put ^ at start and $ at end
		k = k.replace(/\./g, "\\.");// 2: replace . with \.
		k = k.replace(/\*/g, ".*");	// 3: replace * with .*
		globalregex.push(k);
	}

	console.log("PopupKiller: copy of storage contents,");
	console.log(globalstorage);
}




function compareAndKill(tabid, taburl) {
	// never kill any of the firefox internal-use pages
	if(taburl.match(/^about\:.*&/)) { return; }
	if(taburl.match(/((addons)|(support))\.mozilla\.org/)) { return; }	
	// probably should add more 'never-kill' patterns... later
	
	//console.log("testing...");
	for(let i = 0; i < globalregex.length; i++) {
		let reg = globalregex[i];
		//console.log(reg);
		if(taburl.match(reg)) {
			let removing = browser.tabs.remove(tabid);
			removing.then(() => {
				console.log("PopupKiller: page killed " + taburl);
				globalstorage[i][1] += 1;
				addHit(globalstorage[i][0], globalstorage[i][1]);
			}, onError);
			break;
		}
	}
}


function handleWindowCreated(win) { // inactive
	console.log("WindowCreated! WindowID=" + win.id + ", Type=" + win.type + ", TabList=" + win.tabs);
}

function handleTabCreated(tab) { // inactive
	console.log("TabCreated! TabID=" + tab.id + ", URL=" + tab.url + ", WindowID=" + tab.windowId);
}

function handleTabUpdated(tabId, changeInfo, tab) {
	if (changeInfo.url) {
		console.log("PopupKiller: TabUpdated! TabID=" + tabId + ", WindowID=" + tab.windowId + ", URL=" + changeInfo.url );
		
		// definitely needed here
		compareAndKill(tab.id, tab.url);
	}
}

function handleEditMessage(message) {
	console.log("PopupKiller: message received,");
	console.log(message);
	if(message.PUKadd) {
		addStorage(message.PUKadd);
	} else if(message.PUKrem) {
		removeStorage(message.PUKrem);
	} else if(message.PUKclr) {
		if(message.PUKclr == "confirm") {
			clearStorage();
		}
	}
	// otherwise it's not a message meant for me, probably
}


//browser.windows.onCreated.addListener(handleWindowCreated);
//browser.tabs.onCreated.addListener(handleTabCreated);
browser.tabs.onUpdated.addListener(handleTabUpdated);
browser.runtime.onMessage.addListener(handleEditMessage);
readStorage();
console.log("PopupKiller: init BG script"); 

// testing code:
/*
clearStorage();
addStorage("*primosearch.com*");
addStorage("*www.nextlnk1.com*");
addStorage("*serve.popads.net*");
addStorage("*www.adexchangecloud.com*");
addStorage("*www.hicpm5.com*");
addStorage("*cdnondemand.org*");

addStorage("KILLME");
addStorage("*KILLAME*");
*/

