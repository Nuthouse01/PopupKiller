/* Brian Henson 1/24/2018 */

/* 
initialize
 */
// set up variables connected to the existing parts of the balloon
console.log("PopupKiller: balloon launch!");

var inputPattern = document.querySelector('.new-pattern input');
var patternContainer = document.querySelector('.pattern-container');
var addBtn = document.querySelector('.add');
// basically a copy of all the info in storage
var globalstorage = [];
// how small is too small for a pattern?
var patterntoosmall = 7;
// attach listeners to existing parts of balloon
addBtn.addEventListener('click', addNewPattern);
// fill out the balloon with existing entries
readStorage();



// readStorage() -> populate()
// fills out the balloon with all existing entries
function readStorage() {
	var gettingItem = browser.storage.local.get(); // get everything
	gettingItem.then(populate, onError);
}
function populate(result) {
	// creates a list of pattern:hits pairs, list of lists
	globalstorage = Object.entries(result);
	// sort it by pattern, hopefully
	globalstorage.sort();
	// call insertDiv() for each entry
	for(let i = 0; i < globalstorage.length; i++) {
		insertDiv(globalstorage[i], i);
	}
}


// addNewPattern:
function addNewPattern() {
	// save the text and clear the text box, whether it's valid or not
	var newPattern = inputPattern.value;
	inputPattern.value = '';
	
	// clean/validate the input; returns empty string if bad
	var cleanPattern = validateInput(newPattern);
	if(cleanPattern == '') { return; }
	
	// build a pattern:hits pair, insert into list, sort, find its new index
	var newpair = [ cleanPattern, 0 ];
	globalstorage.push(newpair);
	globalstorage.sort();
	var pos = globalstorage.indexOf(newpair);
	
	// build the table entry
	insertDiv(newpair, pos);	
	
	// send message to BG script
	notifyBGadd(cleanPattern);
}


// NOTE: is argument the position # or the node at that position? how to get one from the other?
function insertDiv(newpair, pos) {
	// should be modular, so a URL can be inserted in the middle of the list
	// Node.insertBefore()
	var patternTable = document.querySelector('.pattern-table');
	
	var urlText = document.createElement('td');
	    urlText.setAttribute('class','pattern-text');
	    urlText.textContent = newpair[0];
	var numHits = document.createElement('td');
	    numHits.setAttribute('class','num-hits');
	    numHits.textContent = newpair[1];
	var deleteBtn = document.createElement('button');
	    deleteBtn.setAttribute('class','delete');
	    deleteBtn.textContent = 'Delete';
	
	var btnCell = document.createElement('td');
	    btnCell.appendChild(deleteBtn);
	var patternRow = document.createElement('tr');
	    patternRow.appendChild(urlText);
	    patternRow.appendChild(numHits);
	    patternRow.appendChild(btnCell);
	
	// attach listener to delete button
	deleteBtn.addEventListener('click',(e) => {
		// delete the row, hopefully
		const evtTgt = e.target;
		evtTgt.parentNode.parentNode.parentNode.removeChild(evtTgt.parentNode.parentNode);
		// send message to BG script
		notifyBGremove(newpair[0]);
		// remove from sorted global list
		globalstorage.splice(globalstorage.indexOf(newpair),1);
	})

	// turn pos number into a node or null
	//console.log(patternTable.childNodes);
	//console.log(patternTable.childNodes.length);
	var beforeme = null;
	if(patternTable.childNodes.length > (pos + 4)) {
		beforeme = patternTable.childNodes[pos + 4];
	}
	
	// do the insertNode thing
	patternTable.insertBefore(patternRow, beforeme);
}

// removePattern:
// function removePattern(e) {
	// const evtTgt = e.target;
	// evtTgt.parentNode.parentNode.parentNode.removeChild(evtTgt.parentNode.parentNode);
	// send message to BG script
	// remove from sorted global list
	// delete the div
// }


// validateInput:
// NOTE: can tabs/newlines go into the textbox? make tab cycle, newline adds!
function validateInput(rawinputstring) {
	let WIP = rawinputstring.replace(/\n/gm,'');// remove all newlines, from anywhere
	WIP = WIP.replace(/^\s+|\s+$/g,'');			// remove whitespace from the ends
	WIP = WIP.replace(/\*+/g,'*');				// compress multi-stars
	if(WIP == '') {
		return '';
	}
	// compare against known safe sites
	if(WIP.match(/mozilla/i) || WIP.match(/yahoo/i) || 
	   WIP.match(/google/i)  || WIP.match(/gmail/i) ){
		// error: you probably don't want to add this URL
		myError("Err: this pattern '" + WIP + "' might be a known-safe website!");
		return '';
	}
	// check total length (if pattern is too short, increases chance of false positive)
	if(WIP.length < patterntoosmall) {
		myError("Err: the given pattern '" + WIP + "' is dangerously short.");
		return '';
	}
	// check if it's already an existing pattern
	for (thing of globalstorage) {
		if(WIP == thing[0]) {
			return ''; // abort quietly
		}
	}
	return WIP;
}


function myError(errtext) {
	var errspot = document.querySelector('.errorparagraph');
	errspot.textContent = errtext;
	console.error(`PopupKiller balloon: error: ${errtext}`);
}



function onError(error) {
	console.error(`Error: ${error}`);
}

function notifyBGadd(urltosend) {
	var sending = browser.runtime.sendMessage({  PUKadd: urltosend  });
	sending.then(() => {
		console.log("PopupKiller balloon: message: add " + urltosend + " to klist");
	}, onError);  
}

function notifyBGremove(urltosend) {
	var sending = browser.runtime.sendMessage({  PUKrem: urltosend  });
	sending.then(() => {
		console.log("PopupKiller balloon: message: remove " + urltosend + " from klist");
	}, onError);  
}

// no intention of hooking up this function
function notifyBGclear() {
	var sending = browser.runtime.sendMessage({  PUKclr: "confirm"  });
	sending.then(() => {
		console.log("PopupKiller balloon: message: clear klist");
	}, onError);  
}


